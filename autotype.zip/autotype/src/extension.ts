import * as vscode from "vscode";

export function activate(context: vscode.ExtensionContext) {

  vscode.window.showInformationMessage("Your autotyping has been activated.");

  let x = vscode.commands.registerCommand("autotyping.autotyping", () => {
    // Command logic here (if any)
  });

  context.subscriptions.push(x);

  let isTypingByExtension = false;

  vscode.workspace.onDidChangeTextDocument(async (event) => {
    if (!isTypingByExtension) {
      const document = event.document;
      const fileType = document.languageId;

 
      if (isSupportedFileType(fileType)) {
        const changes = event.contentChanges[0];

        if (isPaste(changes)) {
          isTypingByExtension = true;
          await simulateTyping(changes.range, changes.text);
          setTimeout(() => {
            isTypingByExtension = false;
          }, changes.text.split("\n").length * 50);


        } else {


          
          event.contentChanges.forEach((change) => {
            vscode.commands.executeCommand("default:type", {
              text: change.text,
            });
          });
        }
      }
    }
  });
}

export function deactivate() {}

function isSupportedFileType(fileType: string): boolean {

  const supportedTypes = [
    "html",
    "css",
    "javascript",
    "python",
    "java",
    "typescript",
    "csharp",
    "php",
    "ruby",
    "markdown",
    "json",
    "xml",
    "yaml",
    "swift",
    "go",
    "rust",
    "kotlin",
    "scala",
    "r",
    "powershell",
    "haskell",
    "dart",
    "groovy",
    "lua",
    "perl",
    "shellscript",
    "objective-c",
    "matlab",
    "coffee",
    "vb",
    "plaintext",
  ];

  return supportedTypes.includes(fileType.toLowerCase());
}

function isPaste(changes: vscode.TextDocumentContentChangeEvent): boolean {
  return changes.text.length > 0 && changes.rangeLength === 0;
}

async function simulateTyping(pastedRange: vscode.Range, typedText: string) {
  const editor = vscode.window.activeTextEditor;
  if (editor) {
    await editor.edit((editBuilder) => {
 
      const currentLine = editor.document.lineAt(pastedRange.start.line);
      const rangeToDelete = new vscode.Range(
        currentLine.range.start,
        currentLine.range.end
      );
      editBuilder.delete(rangeToDelete);
    });

    const delay = 100; 

    for (let i = 0; i < typedText.length; i++) {
      const char = typedText.charAt(i);
      await sleep(delay);

 
      editor.edit((editBuilder) => {
        editBuilder.insert(editor.selection.start, char);
      });
    }
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}



